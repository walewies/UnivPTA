#include "loop.h"

void printCollatz(int num){
    //Add your implementation here
}

void printSquares(int n){
    //Add your implementation here
}

void printDiamond(int halfSize){
    //Add your implementation here
}