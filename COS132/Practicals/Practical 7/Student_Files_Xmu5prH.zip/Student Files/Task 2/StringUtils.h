#ifndef STRING_UTILS_H
#define STRING_UTILS_H
#include <string>
using namespace std;
string returnDecodedString(string input, int shift);
#endif