#include "Maths.h"

float sum(float x, float y){
    return x + y; 
}

float subtract(float x, float y){
    return x - y;
}

float multiply(float x, float y){
    return x * y; 
}

float divide(float x, float y){
    return x / y;
}