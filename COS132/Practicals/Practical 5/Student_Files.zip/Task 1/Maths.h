#ifndef Maths_h
#define Maths_h

float sum(float, float);
float subtract(float, float);
float multiply(float, float);
float divide(float, float);

#endif