#ifndef Advanced_Maths_h
#define Advanced_Maths_h

float squareRoot(float);
float areaOfCircle(float);
float areaOfTriangle(float, float);

#endif