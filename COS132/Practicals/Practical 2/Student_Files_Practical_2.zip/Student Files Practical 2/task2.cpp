#include <iostream>
#include <string>

int main() {
    /**
     * ***************************** *
     * Part 1: Setting up Inventory  *
     * ***************************** * 
    */

    // Declare all your variables for Part 1 here:


    /* DO NOT CHANGE THIS CODE! */
    std::cout<<"###"<<std::endl;
    std::cout<<"Best-selling item: "<<bestSellingItem<<std::endl;
    std::cout<<"Cup size for best-seller: "<<cupSize<<std::endl;
    std::cout<<"Number of coffee bean bags in stock: "<<beanStock<<std::endl;
    std::cout<<"Number of milk cartons in stock: "<<milkStock<<std::endl;
    std::cout<<"Cafe open: "<<cafeOpen<<std::endl;
    std::cout<<"Restock needed: "<<restockNeeded<<std::endl;
    std::cout<<"Sales in rands: R"<<sales<<std::endl;
    std::cout<<"###"<<std::endl;

    /**
     * ************************************ *
     * Part 2: Daily Inventory Calculation  *
     * ************************************ * 
    */

    // Your code for Part 2 goes here:


    /*DO NOT CHANGE CODE BELOW THIS LINE*/
    std::cout<<"###"<<std::endl;


}