#ifndef INT_H
#define INT_H

int findInt(int target, int current = 0);
char convertChar(int character);
#endif