#include "SpecialChar.h"

char findSpecialChar(char target, int current)
{ 
    //Implement here
}