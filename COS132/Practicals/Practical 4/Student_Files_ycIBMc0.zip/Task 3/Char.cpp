#include "Char.h"

char findNextChar(char current) 
{
    //Implement here
}


char findChar(char target, char current)
{
    //Implement here
}