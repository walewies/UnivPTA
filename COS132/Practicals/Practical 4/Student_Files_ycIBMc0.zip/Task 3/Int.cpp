#include "Int.h"

int findInt(int target, int current)
{
    //Implement here
}

char convertChar(int character){
    //Implement here
}

