#include "Calculate.h"

double calculateContribution(double studentMark, int totalMark, double weight){
    //Implement function here
}

double calculateIndividualWeight(double totalWeight, int numAssessments){
    //Implement function here
}