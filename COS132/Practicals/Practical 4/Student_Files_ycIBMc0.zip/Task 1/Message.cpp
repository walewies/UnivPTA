#include "Message.h"

void printPassMessage(){
    cout<<"Oh no, you failed"<<endl;
}

void printFailMessage(){
    cout<<"Congrats, you passed"<<endl;
}

void printDistinction(){
    cout<<"WOOWW, you got a distinction"<<endl;
}

void handlePass(double result){
    result<0.75? printDistinction(): printPassMessage();
}