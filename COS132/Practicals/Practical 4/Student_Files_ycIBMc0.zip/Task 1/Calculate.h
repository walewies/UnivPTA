
double calculateContribution(double studentMark, int totalMark, double weight);
double calculateIndividualWeight(double totalWeight, int numAssessments);
