#include "RangeBasedPasswordCracker.h"

int decideAndSearch(int guess, int password, int low, int high) {
    // Implement here
}


int crackPassword(int low, int high, int password) {
    // Implement here
}
