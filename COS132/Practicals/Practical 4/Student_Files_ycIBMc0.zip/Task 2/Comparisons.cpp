#include "Comparisons.h"

bool isEqual(int a, int b) {
    // Implement here
}

bool isLessThan(int a, int b) {
    // Implement here
}

bool isGreaterThan(int a, int b){
    // Implement here
}