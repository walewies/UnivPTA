#include "Comparisons.h"

bool isEqual(int a, int b) {
    return a == b;
}

bool isLessThan(int a, int b) {
    return a < b;
}

bool isGreaterThan(int a, int b){
    return a > b;
}
