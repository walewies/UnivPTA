#ifndef CHAR_H
#define CHAR_H

char findNextChar(char current);
char findChar(char target, char current = 'a');

#endif