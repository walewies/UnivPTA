#ifndef MESSAGE_H
#define MESSAGE_H

#include <iostream>
using namespace std;

void printPassMessage();

void printFailMessage();

void printDistinction();

void handlePass(double result);

#endif
