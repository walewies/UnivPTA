#ifndef POISON_DILUTE_H
#define POISON_DILUTE_H
int* findNthLargest(int *arr, int size, int n, int *largest);
#endif