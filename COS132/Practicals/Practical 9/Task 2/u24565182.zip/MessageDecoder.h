#ifndef MESSAGE_DECODER_H
#define MESSAGE_DECODER_H
int findIndex(char c);
void decodeBase64(const char encoded[], char decoded[], int encodedLength);
#endif