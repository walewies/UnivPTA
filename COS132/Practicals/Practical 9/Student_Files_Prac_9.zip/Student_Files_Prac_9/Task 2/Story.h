#ifndef STORY_H
#define STORY_H

void part1();
void part2();
void part3();

#endif