#ifndef DATABASE_CORRUPTION_H
#define DATABASE_CORRUPTION_H

#include <iostream>
using namespace std;
void corruptDatabase(int securityLevel);
void initiateCorruptionSequence();
void finalizeCorruption();

#endif