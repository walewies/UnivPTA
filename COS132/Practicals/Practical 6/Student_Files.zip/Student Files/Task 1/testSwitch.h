#ifndef TEST_SWITCH_H
#define TEST_SWITCH_H

void testDayOfWeek(int day);

void switchRanges(int score);


#endif