#include "testSwitch.h"
#include <iostream>
using namespace std;

void testDayOfWeek(int day){
    switch (day) {
        case 1:
            cout << "Monday\n";
        case 2:
            cout << "Tuesday\n";
        case 3:
            cout << "Wednesday\n";
        case 4:
            cout << "Thursday\n";
        default:
            cout << "Some other day\n";
    }
}

void switchRanges(int score){
    switch (score) {
    case (score<50):
        cout << "Fail" << endl;
        break;
    case  (score<75):
        cout << "Pass" << endl;
        break;
    case  (score<=100):
        cout << "Excellent" << endl;
        break;
    default:
        cout << "Invalid score" << endl;
    }
}
