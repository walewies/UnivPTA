#include <iostream>

using namespace std;

int main(){
    //ADD YOUR SOLUTION HERE
    //PASTE THIS INTO THE ONLINE COMPILER AND EDIT THERE!!!!
}