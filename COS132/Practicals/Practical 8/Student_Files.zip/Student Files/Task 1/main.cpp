#include "task1.h"
#include <cassert>
#include <iostream>

using namespace std;

int main()
{

    // Add your tests here
    // You can use assert for tests
    return 0;
}
